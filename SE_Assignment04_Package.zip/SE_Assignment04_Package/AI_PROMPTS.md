# AI prompts for Assignment #04 (send these to Claude.ai)

How to use:
1. Open a NEW chat in Claude.ai for each prompt (or keep one chat, but send them in order).
2. Replace each [PASTE ...] part with the real file text from this project (open the file, copy all, paste).
3. Take a screenshot of your prompt AND of the AI answer. Put the screenshots into the report, Appendix B.
4. Read the answer. Write down what you used, what was wrong, and what you changed (Appendix A, "AI-use record").
Do not send passwords, keys or private data. Everything here is fictional.

---------------------------------------------------------------
## PROMPT 1 - Codebase analysis (Task 1)
---------------------------------------------------------------
I am a software engineering student. I have a small web app called "Smart Campus Room Availability Checker".
Please analyze it. Do NOT write or change code yet.

PROJECT MAP (initial version, one room):
- initial/index.html : page layout, static text "Existing booking: 10:00-11:00"
- initial/app.js     : click handler, reads inputs, hard-coded bookings, builds result HTML
- initial/booking.js : function canBook({ start, end, now, blocked, bookings }) -> true/false

ACCEPTANCE CRITERIA (must stay true):
AC1 reject start >= end and requests in the past (start <= now) or after midnight (end > 1440)
AC2 maximum duration is 120 minutes (120 is allowed, 121 is not)
AC3 a blocked room is rejected
AC4 overlapping bookings are rejected, but bookings that only touch at the endpoints are allowed
AC5 the answer is Available / Unavailable and the booking data is never changed
AC6 clear feedback on desktop and mobile

CONSTRAINTS: no login, no payments, no live API, no database. Fictional data only. Time = minutes after midnight, fixed current time 09:00 (540).

NEW REQUIREMENTS I WILL ADD LATER:
A catalog of at least 4 rooms (id, name, capacity, equipment list, blocked status, own bookings).
F1 capacity >= requested people. F2 room has ALL selected equipment. F3 blocked room is never available.
F4 clear empty state when no room matches. F5 changing the selected room refreshes the result.

TASKS FOR YOU:
1. Find at least THREE maintainability risks. For each one give the file, the function and the line or code fragment.
2. Give a prioritized improvement plan (1 = do first) with one sentence of reason for each step.
3. Do not rewrite the project. Do not give full code.

[PASTE initial/app.js]
[PASTE initial/booking.js]
[PASTE initial/index.html]

---------------------------------------------------------------
## PROMPT 2 - Small implementation plan (Task 2 and Task 3)
---------------------------------------------------------------
Thank you. Now give me a SMALL implementation plan, not a full rewrite.

Goal: add a room catalog (at least 4 fictional rooms) with capacity and equipment filters (F1-F5 from above),
and reorganize the code so that these parts are separate:
(a) room data, (b) booking/availability rules, (c) filtering logic, (d) UI presentation.

Please answer with:
1. A list of modules/files (name + one-line responsibility).
2. The order of changes, one small change at a time, and which test to run after each change.
3. How to remove the duplicated validation and the duplicated result HTML.
4. TWO design decisions with a short reason for each.
5. How to keep canBook() working for the 19 old tests.
No full code, only the plan.

---------------------------------------------------------------
## PROMPT 3 - Review of the final code (Task 3 and Task 4)
---------------------------------------------------------------
Please review my refactored code. Do not rewrite it. Only report problems.
Check it against AC1-AC5 and F1-F5 (listed above).

For each problem give: file + function, what is wrong, an input that shows it, and the smallest fix.
Also say clearly if you found NO problem in an area. Do not invent problems.
Separate "confirmed by reading the code" from "only a guess".

[PASTE final/src/rules/booking.js]
[PASTE final/src/logic/filter.js]
[PASTE final/src/logic/availability.js]
[PASTE final/src/logic/controller.js]
[PASTE final/src/ui/render.js]
[PASTE final/src/data/rooms.js]

---------------------------------------------------------------
## PROMPT 4 - Test review (Task 4)
---------------------------------------------------------------
Here is the output of my test run (Vitest, verbose). Please review the test list.
Tell me: (1) which important cases are missing, especially boundaries
(120 vs 121 minutes, touching vs overlapping, exact capacity vs not enough capacity),
(2) which tests are weak (they could pass with wrong code), (3) three small deliberate bugs I could put in the code
to check that my tests fail when they should. Do not write the full test file.

[PASTE the output of:  npx vitest run final --reporter=verbose]

---------------------------------------------------------------
## PROMPT 5 - Check my quality table (Task 5)
---------------------------------------------------------------
Below is my short evidence table that compares the initial and the final version.
Please check it: is any number missing an explanation of how it was measured? Is any claim not supported by evidence?
Do not add new numbers. Only point out weak or unsupported statements.

[PASTE the table from Section 5 of the report]
