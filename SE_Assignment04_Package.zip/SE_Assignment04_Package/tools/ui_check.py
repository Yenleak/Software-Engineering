"""Optional real-browser check of the final UI (needs: pip install playwright; playwright install chromium).
Start the server first:  python -m http.server 8765   (run it in the project root)
Run:  python tools/ui_check.py
"""
from playwright.sync_api import sync_playwright

URL = 'http://localhost:8765/final/index.html'
checks = []

def check(name, ok):
    checks.append((name, ok)); print(('PASS ' if ok else 'FAIL ') + name)

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 900, 'height': 1000}); pg.goto(URL)
    check('5 rooms are shown at start', pg.locator('#rooms .room').count() == 5)
    pg.fill('#attendees', '10'); pg.check('#equipment input[value=whiteboard]')
    check('F1+F2: 10 people + whiteboard shows 2 rooms', pg.locator('#rooms .room').count() == 2)
    pg.fill('#attendees', '100')
    check('F4: empty state is shown when no room matches', 'No rooms match' in pg.inner_text('#rooms'))
    pg.fill('#attendees', '0'); pg.uncheck('#equipment input[value=whiteboard]')
    pg.check('input[value=R101]'); pg.fill('#start', '10:30'); pg.fill('#end', '11:30'); pg.click('#check')
    check('AC4: Lecture Hall A is unavailable at 10:30-11:30', 'overlaps an existing booking' in pg.inner_text('#result'))
    pg.check('input[value=R102]')
    check('F5: switching to Computer Lab 1 refreshes to Available', 'Available' in pg.inner_text('#result'))
    pg.check('input[value=R104]')
    check('F3: blocked room is unavailable', 'blocked' in pg.inner_text('#result'))
    pg.check('input[value=R103]'); pg.fill('#end', '12:31')
    check('AC2: 121 minutes is rejected', '120 minutes' in pg.inner_text('#result'))
    pg.set_viewport_size({'width': 390, 'height': 1500})
    check('AC6: no sideways scrolling on a phone width', not pg.evaluate('document.documentElement.scrollWidth > window.innerWidth'))
    b.close()
print(f"{sum(ok for _, ok in checks)}/{len(checks)} UI checks passed")
