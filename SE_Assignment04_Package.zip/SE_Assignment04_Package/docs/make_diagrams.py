import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

def box(ax, x, y, w, h, title, lines, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.15', fc=color, ec='#334', lw=1.3))
    ax.text(x + w/2, y + h - 0.28, title, ha='center', va='top', fontsize=10.5, fontweight='bold', family='DejaVu Sans')
    for i, l in enumerate(lines):
        ax.text(x + 0.18, y + h - 0.75 - i*0.33, l, ha='left', va='top', fontsize=8.3, family='DejaVu Sans')

def arrow(ax, x1, y1, x2, y2, label=''):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='->', lw=1.4, color='#223'))
    if label: ax.text((x1+x2)/2 + 0.08, (y1+y2)/2, label, fontsize=8, color='#223')

# BEFORE
fig, ax = plt.subplots(figsize=(10, 5.2)); ax.set_xlim(0, 10); ax.set_ylim(0, 5.2); ax.axis('off')
ax.text(5, 5.0, 'BEFORE: initial version (3 files, one room)', ha='center', fontsize=13, fontweight='bold')
box(ax, 0.3, 0.6, 2.6, 3.6, 'index.html', ['Page layout', 'Static text:', '"Existing booking', ' 10:00-11:00"', '(copy of data)'], '#e8eef9')
box(ax, 3.7, 0.6, 3.4, 3.6, 'app.js  (UI + rules mixed)', ['Reads inputs', 'Hard-coded bookings', 'Checks start < end   (copy)', 'Checks 120 minutes   (copy)', 'Checks overlap       (copy)', 'Builds 4 result HTML strings', 'Converts time (toMin / fmt)'], '#fde8d9')
box(ax, 7.9, 0.6, 1.9, 3.6, 'booking.js', ['canBook()', 'returns only', 'true / false', '', 'AC1 - AC5 rules'], '#d9f5df')
arrow(ax, 2.9, 2.4, 3.7, 2.4, 'loads'); arrow(ax, 7.1, 2.4, 7.9, 2.4, 'calls')
plt.savefig('docs/diagram_before.png', dpi=140, bbox_inches='tight'); plt.close()

# AFTER
fig, ax = plt.subplots(figsize=(10.5, 7)); ax.set_xlim(0, 10.5); ax.set_ylim(0, 7); ax.axis('off')
ax.text(5.25, 6.8, 'AFTER: final version (separate responsibilities)', ha='center', fontsize=13, fontweight='bold')
box(ax, 0.2, 5.0, 2.6, 1.4, 'index.html + styles.css', ['Layout only', 'Responsive rules'], '#e8eef9')
box(ax, 3.4, 5.0, 3.0, 1.4, 'main.js', ['Reads inputs, keeps state', 'Calls evaluate(), shows HTML'], '#fde8d9')
box(ax, 7.1, 5.0, 3.2, 1.4, 'ui/render.js', ['Builds all HTML text', 'ONE result card template'], '#fde8d9')
box(ax, 3.4, 2.9, 3.0, 1.6, 'logic/controller.js', ['evaluate(state, rooms, now)', 'filter + selected room + result', 'Pure: no DOM'], '#fff3cd')
box(ax, 0.2, 1.0, 2.8, 1.6, 'logic/filter.js', ['F1 capacity', 'F2 all equipment'], '#fff3cd')
box(ax, 3.6, 1.0, 3.0, 1.6, 'logic/availability.js', ['checkAvailability(room, ...)', 'uses the chosen room only'], '#fff3cd')
box(ax, 7.2, 1.0, 3.1, 1.6, 'rules/booking.js', ['checkRequest()  - AC1 to AC5', 'canBook() = checkRequest().ok', 'rules written ONCE'], '#d9f5df')
box(ax, 7.2, 3.0, 3.1, 1.5, 'rooms.js + time.js', ['5 fictional rooms (own bookings)', 'toMinutes / formatTime'], '#e4e0f5')
arrow(ax, 2.8, 5.7, 3.4, 5.7); arrow(ax, 6.4, 5.7, 7.1, 5.7); arrow(ax, 4.9, 5.0, 4.9, 4.5)
arrow(ax, 3.9, 3.0, 2.1, 2.6); arrow(ax, 4.9, 3.0, 4.9, 2.6); arrow(ax, 6.6, 1.8, 7.2, 1.8)
arrow(ax, 6.4, 3.75, 7.2, 3.75)
plt.savefig('docs/diagram_after.png', dpi=140, bbox_inches='tight'); plt.close()
