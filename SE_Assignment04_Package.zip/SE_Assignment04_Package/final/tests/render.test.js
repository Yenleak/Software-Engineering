import { describe, test, expect } from 'vitest';
import { ROOMS, NOW } from '../src/data/rooms.js';
import { escapeHtml, renderResult, renderRoomList } from '../src/ui/render.js';

const room = ROOMS[0];

describe('screen text (UI behavior)', () => {
  test('overlap message shows the existing booking time', () => {
    const html = renderResult({ available: false, reason: 'overlap', conflict: { start: 600, end: 660 } }, room, NOW);
    expect(html).toContain('10:00 - 11:00');
    expect(html).toContain('unavailable');
  });
  test('validation problems use the error style with a clear message', () => {
    const html = renderResult({ available: false, reason: 'too_long', conflict: null }, room, NOW);
    expect(html).toContain('error');
    expect(html).toContain('120 minutes');
  });
  test('blocked room is marked in the room list', () => {
    const html = renderRoomList([ROOMS[3]], null);
    expect(html).toContain('Blocked');
  });
  test('selected room is checked in the list', () => expect(renderRoomList(ROOMS, 'R102')).toContain('value="R102" checked'));
  test('special characters are escaped', () => expect(escapeHtml('<b>"x"</b>')).toBe('&lt;b&gt;&quot;x&quot;&lt;/b&gt;'));
});
