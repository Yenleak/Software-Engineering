import { describe, test, expect } from 'vitest';
import { canBook, checkRequest } from '../src/rules/booking.js';

const fx = (o = {}) => ({ now: 540, blocked: false, bookings: [{ start: 600, end: 660 }], ...o });
const run = (start, end, o = {}) => {
  const input = { start, end, ...fx(o) };
  const before = JSON.stringify(input.bookings);
  const result = canBook(input);
  return { result, unchanged: JSON.stringify(input.bookings) === before };
};

describe('AC1 - invalid time ranges (regression)', () => {
  test('T02 starts now (540-570) -> false', () => expect(run(540, 570).result).toBe(false));
  test('T03 zero duration (720-720) -> false', () => expect(run(720, 720).result).toBe(false));
  test('T04 reversed (750-720) -> false', () => expect(run(750, 720).result).toBe(false));
  test('T05 past day end (1380-1441) -> false', () => expect(run(1380, 1441).result).toBe(false));
  test('X1 starts in the past (480-540) -> false', () => expect(run(480, 540).result).toBe(false));
});
describe('AC2 - max duration 120 (regression)', () => {
  test('T06 exactly 120 (720-840) -> true', () => expect(run(720, 840).result).toBe(true));
  test('T07 121 minutes (720-841) -> false', () => expect(run(720, 841).result).toBe(false));
});
describe('AC3 - blocked room (regression)', () => {
  test('T13 blocked (660-720) -> false', () => expect(run(660, 720, { blocked: true }).result).toBe(false));
});
describe('AC4 - overlaps (regression)', () => {
  test('T01 touching after (660-720) -> true', () => expect(run(660, 720).result).toBe(true));
  test('T08 touching before (570-600) -> true', () => expect(run(570, 600).result).toBe(true));
  test('T09 partial overlap (630-690) -> false', () => expect(run(630, 690).result).toBe(false));
  test('T10 contains booking (570-690) -> false', () => expect(run(570, 690).result).toBe(false));
  test('T11 inside booking (615-645) -> false', () => expect(run(615, 645).result).toBe(false));
  test('T12 identical (600-660) -> false', () => expect(run(600, 660).result).toBe(false));
  test('T14 no bookings (630-690) -> true', () => expect(run(630, 690, { bookings: [] }).result).toBe(true));
  test('X2 touches two bookings, fits the gap -> true', () =>
    expect(run(660, 720, { bookings: [{ start: 600, end: 660 }, { start: 720, end: 780 }] }).result).toBe(true));
});
describe('AC5 - data preserved (regression)', () => {
  test('available result keeps bookings unchanged', () => { const r = run(660, 720); expect(r.result).toBe(true); expect(r.unchanged).toBe(true); });
  test('unavailable result keeps bookings unchanged', () => { const r = run(630, 690); expect(r.result).toBe(false); expect(r.unchanged).toBe(true); });
  test('repeated checks give the same answer', () => {
    const input = { start: 660, end: 720, ...fx() };
    const before = JSON.stringify(input.bookings);
    expect(canBook(input)).toBe(true); expect(canBook(input)).toBe(true);
    expect(JSON.stringify(input.bookings)).toBe(before);
  });
});
describe('reasons returned by checkRequest', () => {
  test('missing time gives missing_time', () => expect(checkRequest({ start: NaN, end: 700, ...fx() }).reason).toBe('missing_time'));
  test('overlap gives overlap and the conflicting booking', () => {
    const r = checkRequest({ start: 630, end: 690, ...fx() });
    expect(r.reason).toBe('overlap');
    expect(r.conflict).toEqual({ start: 600, end: 660 });
  });
  test('121 minutes gives too_long', () => expect(checkRequest({ start: 720, end: 841, ...fx() }).reason).toBe('too_long'));
});
