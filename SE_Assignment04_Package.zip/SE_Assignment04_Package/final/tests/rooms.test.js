import { describe, test, expect } from 'vitest';
import { ROOMS } from '../src/data/rooms.js';

describe('room catalog', () => {
  test('has at least four rooms', () => expect(ROOMS.length).toBeGreaterThanOrEqual(4));
  test('every room has id, name, capacity, equipment, blocked and bookings', () => {
    for (const r of ROOMS) {
      expect(typeof r.id).toBe('string');
      expect(typeof r.name).toBe('string');
      expect(typeof r.capacity).toBe('number');
      expect(Array.isArray(r.equipment)).toBe(true);
      expect(typeof r.blocked).toBe('boolean');
      expect(Array.isArray(r.bookings)).toBe(true);
    }
  });
  test('room ids are unique', () => expect(new Set(ROOMS.map((r) => r.id)).size).toBe(ROOMS.length));
});
