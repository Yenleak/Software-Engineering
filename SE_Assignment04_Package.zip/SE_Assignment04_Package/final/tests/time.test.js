import { describe, test, expect } from 'vitest';
import { toMinutes, formatTime } from '../src/rules/time.js';

describe('time helpers', () => {
  test('toMinutes converts 09:30 to 570', () => expect(toMinutes('09:30')).toBe(570));
  test('toMinutes returns NaN for empty or invalid text', () => {
    expect(Number.isNaN(toMinutes(''))).toBe(true);
    expect(Number.isNaN(toMinutes('25:00'))).toBe(true);
  });
  test('formatTime converts 570 to 09:30', () => expect(formatTime(570)).toBe('09:30'));
});
