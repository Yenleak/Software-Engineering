import { describe, test, expect } from 'vitest';
import { ROOMS, NOW } from '../src/data/rooms.js';
import { evaluate } from '../src/logic/controller.js';
import { renderEmptyState, renderResult } from '../src/ui/render.js';

const base = { attendees: 0, equipment: [], roomId: null, start: NaN, end: NaN, checked: false };

describe('integration: filter + availability + screen text', () => {
  test('F4 - no matching room shows the empty state', () => {
    const out = evaluate({ ...base, attendees: 100 }, ROOMS, NOW);
    expect(out.visibleRooms).toHaveLength(0);
    expect(renderEmptyState()).toContain('No rooms match');
  });
  test('F5 - switching the room refreshes the result', () => {
    const state = { ...base, roomId: 'R101', start: 630, end: 690, checked: true };
    expect(evaluate(state, ROOMS, NOW).result.available).toBe(false);          // Lecture Hall A is busy
    expect(evaluate({ ...state, roomId: 'R102' }, ROOMS, NOW).result.available).toBe(true); // Computer Lab 1 is free
    const blocked = evaluate({ ...state, roomId: 'R104' }, ROOMS, NOW).result;
    expect(blocked.reason).toBe('blocked');                                    // Meeting Room B is blocked
  });
  test('selected room that does not match the filters gives no result', () => {
    const state = { ...base, attendees: 50, roomId: 'R103', start: 630, end: 690, checked: true };
    const out = evaluate(state, ROOMS, NOW);
    expect(out.selected).toBe(null);
    expect(out.result).toBe(null);
  });
  test('no result before the user presses Check', () =>
    expect(evaluate({ ...base, roomId: 'R101', start: 630, end: 690 }, ROOMS, NOW).result).toBe(null));
  test('filters and room choice work together', () => {
    const out = evaluate({ ...base, attendees: 10, equipment: ['whiteboard'], roomId: 'R103', start: 600, end: 660, checked: true }, ROOMS, NOW);
    expect(out.visibleRooms.map((r) => r.id)).toEqual(['R101', 'R103']);
    expect(out.result.available).toBe(true);
    expect(renderResult(out.result, out.selected, NOW)).toContain('Available');
  });
  test('evaluating does not change the room catalog', () => {
    const before = JSON.stringify(ROOMS);
    evaluate({ ...base, roomId: 'R105', start: 630, end: 690, checked: true }, ROOMS, NOW);
    expect(JSON.stringify(ROOMS)).toBe(before);
  });
});
