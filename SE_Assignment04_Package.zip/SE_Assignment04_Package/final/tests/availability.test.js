import { describe, test, expect } from 'vitest';
import { ROOMS, NOW } from '../src/data/rooms.js';
import { checkAvailability } from '../src/logic/availability.js';

const room = (id) => ROOMS.find((r) => r.id === id);

describe('F3 - blocked room', () => {
  test('a blocked room is never available, even with a free time', () => {
    const r = checkAvailability(room('R104'), { start: 780, end: 840 }, NOW);
    expect(r.available).toBe(false);
    expect(r.reason).toBe('blocked');
  });
});
describe('availability uses the chosen room bookings only', () => {
  test('Lecture Hall A is busy at 630-690', () =>
    expect(checkAvailability(room('R101'), { start: 630, end: 690 }, NOW).available).toBe(false));
  test('Computer Lab 1 is free at 630-690 (the other room booking is ignored)', () =>
    expect(checkAvailability(room('R102'), { start: 630, end: 690 }, NOW).available).toBe(true));
  test('Lecture Hall A is free at 720-780 (Computer Lab booking is ignored)', () =>
    expect(checkAvailability(room('R101'), { start: 720, end: 780 }, NOW).available).toBe(true));
});
describe('old rules still work for a room', () => {
  test('120 minutes is allowed in a free room (600-720 in Seminar Room)', () =>
    expect(checkAvailability(room('R103'), { start: 600, end: 720 }, NOW).available).toBe(true));
  test('121 minutes is rejected in a free room (600-721 in Seminar Room)', () =>
    expect(checkAvailability(room('R103'), { start: 600, end: 721 }, NOW).available).toBe(false));
  test('touching booking is allowed (Study Room 660-720 between two bookings)', () =>
    expect(checkAvailability(room('R105'), { start: 660, end: 720 }, NOW).available).toBe(true));
  test('checking does not change room data', () => {
    const before = JSON.stringify(ROOMS);
    checkAvailability(room('R101'), { start: 660, end: 720 }, NOW);
    checkAvailability(room('R105'), { start: 630, end: 690 }, NOW);
    expect(JSON.stringify(ROOMS)).toBe(before);
  });
});
