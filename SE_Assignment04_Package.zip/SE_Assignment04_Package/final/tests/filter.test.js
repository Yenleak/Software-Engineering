import { describe, test, expect } from 'vitest';
import { ROOMS } from '../src/data/rooms.js';
import { filterRooms, listEquipment } from '../src/logic/filter.js';

const ids = (list) => list.map((r) => r.id);

describe('F1 - capacity filter', () => {
  test('exact capacity is accepted (30 people -> Computer Lab 1 with capacity 30)', () =>
    expect(ids(filterRooms(ROOMS, { attendees: 30 }))).toEqual(['R101', 'R102']));
  test('insufficient capacity is rejected (31 people)', () =>
    expect(ids(filterRooms(ROOMS, { attendees: 31 }))).toEqual(['R101']));
  test('invalid number of people is treated as no limit', () =>
    expect(filterRooms(ROOMS, { attendees: NaN }).length).toBe(ROOMS.length));
});
describe('F2 - equipment filter', () => {
  test('room must have ALL selected items', () =>
    expect(ids(filterRooms(ROOMS, { equipment: ['projector', 'computers'] }))).toEqual(['R102']));
  test('one missing item removes the room', () =>
    expect(ids(filterRooms(ROOMS, { equipment: ['projector', 'tv'] }))).toEqual([]));
  test('no selected equipment returns all rooms', () =>
    expect(filterRooms(ROOMS, { equipment: [] }).length).toBe(ROOMS.length));
  test('capacity and equipment work together', () =>
    expect(ids(filterRooms(ROOMS, { attendees: 10, equipment: ['whiteboard'] }))).toEqual(['R101', 'R103']));
});
describe('filter safety', () => {
  test('filtering does not change the room data', () => {
    const before = JSON.stringify(ROOMS);
    filterRooms(ROOMS, { attendees: 20, equipment: ['tv'] });
    expect(JSON.stringify(ROOMS)).toBe(before);
  });
  test('equipment list has each item once', () => {
    const items = listEquipment(ROOMS);
    expect(items).toEqual(['computers', 'microphone', 'projector', 'tv', 'whiteboard']);
  });
});
