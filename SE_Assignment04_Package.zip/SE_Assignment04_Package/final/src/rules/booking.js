// The ONLY place where the booking rules (AC1-AC5) are written.
export const MAX_DURATION = 120;
export const DAY_END = 1440;

const fail = (reason, extra = {}) => ({ ok: false, reason, ...extra });

export function checkRequest({ start, end, now, blocked, bookings }) {
  if (!Number.isFinite(start) || !Number.isFinite(end)) return fail('missing_time');
  if (blocked) return fail('blocked');                              // AC3 / F3
  if (!(start < end)) return fail('invalid_range');                 // AC1
  if (start <= now) return fail('in_past');                         // AC1
  if (end > DAY_END) return fail('past_day_end');                   // AC1
  if (end - start > MAX_DURATION) return fail('too_long');          // AC2
  const conflict = bookings.find((b) => start < b.end && end > b.start); // AC4
  if (conflict) return fail('overlap', { conflict });
  return { ok: true, reason: null };                                // AC5: nothing is changed
}

export const canBook = (request) => checkRequest(request).ok;
