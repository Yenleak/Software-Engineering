import { filterRooms } from './filter.js';
import { checkAvailability } from './availability.js';

// state = { attendees, equipment, roomId, start, end, checked }
// Pure function: the UI calls it after every change (F4, F5).
export function evaluate(state, rooms, now) {
  const visibleRooms = filterRooms(rooms, state);
  const selected = visibleRooms.find((room) => room.id === state.roomId) ?? null;
  const result =
    state.checked && selected
      ? checkAvailability(selected, { start: state.start, end: state.end }, now)
      : null;
  return { visibleRooms, selected, result };
}
