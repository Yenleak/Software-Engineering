// Room filtering (F1 capacity, F2 equipment). Does not change the room list.
export function filterRooms(rooms, { attendees = 0, equipment = [] } = {}) {
  const needed = Number.isFinite(attendees) && attendees > 0 ? attendees : 0;
  return rooms.filter(
    (room) =>
      room.capacity >= needed &&                                  // F1
      equipment.every((item) => room.equipment.includes(item))   // F2: ALL items
  );
}

export function listEquipment(rooms) {
  return [...new Set(rooms.flatMap((room) => room.equipment))].sort();
}
