import { checkRequest } from '../rules/booking.js';

// Uses the CHOSEN room's blocked flag and bookings only.
export function checkAvailability(room, { start, end }, now) {
  const result = checkRequest({ start, end, now, blocked: room.blocked, bookings: room.bookings });
  return { roomId: room.id, available: result.ok, reason: result.reason, conflict: result.conflict ?? null };
}
