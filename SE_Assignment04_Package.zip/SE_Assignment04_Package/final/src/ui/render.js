import { formatTime } from '../rules/time.js';
import { MAX_DURATION } from '../rules/booking.js';

export function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// The ONLY place that builds a result card.
const card = (kind, title, text) =>
  `<div class="card ${kind}" role="status"><strong>${escapeHtml(title)}</strong><p>${escapeHtml(text)}</p></div>`;

const KIND = {
  blocked: 'unavailable', overlap: 'unavailable',
  missing_time: 'error', invalid_range: 'error', in_past: 'error', past_day_end: 'error', too_long: 'error',
};

function messageFor(result, now) {
  switch (result.reason) {
    case 'missing_time': return 'Please enter a start time and an end time.';
    case 'blocked': return 'This room is blocked and cannot be booked.';
    case 'invalid_range': return 'The end time must be after the start time.';
    case 'in_past': return `The start time must be after the current time (${formatTime(now)}).`;
    case 'past_day_end': return 'The booking must end before midnight.';
    case 'too_long': return `A booking can be at most ${MAX_DURATION} minutes.`;
    case 'overlap': return `This time overlaps an existing booking (${formatTime(result.conflict.start)} - ${formatTime(result.conflict.end)}).`;
    default: return '';
  }
}

export function renderResult(result, room, now) {
  if (!room) return card('info', 'Choose a room', 'Select a room from the list to check it.');
  if (!result) return card('info', room.name, 'Enter a start and end time, then press "Check availability".');
  if (result.available) return card('available', 'Available', `${room.name} is free for this time.`);
  return card(KIND[result.reason], 'Unavailable', messageFor(result, now));
}

export function renderEmptyState() {
  return card('empty', 'No rooms match', 'Try fewer people or fewer equipment items.');
}

export function renderRoomList(rooms, selectedId) {
  return rooms.map((room) => {
    const booked = room.bookings.length
      ? room.bookings.map((b) => `${formatTime(b.start)} - ${formatTime(b.end)}`).join(', ')
      : 'none';
    return `<label class="room${room.id === selectedId ? ' selected' : ''}">` +
      `<input type="radio" name="room" value="${escapeHtml(room.id)}"${room.id === selectedId ? ' checked' : ''}>` +
      `<span><strong>${escapeHtml(room.name)}</strong>${room.blocked ? ' <em class="tag">Blocked</em>' : ''}<br>` +
      `Capacity: ${room.capacity} | Equipment: ${escapeHtml(room.equipment.join(', '))}<br>` +
      `Booked: ${escapeHtml(booked)}</span></label>`;
  }).join('');
}

export function renderEquipmentOptions(items, selected) {
  return items.map((item) =>
    `<label class="chip"><input type="checkbox" value="${escapeHtml(item)}"${selected.includes(item) ? ' checked' : ''}> ${escapeHtml(item)}</label>`
  ).join('');
}
