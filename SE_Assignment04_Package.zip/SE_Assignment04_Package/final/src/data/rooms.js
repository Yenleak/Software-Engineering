// Fictional room catalog. Each room owns its bookings (minutes after midnight).
export const NOW = 540; // 09:00, fixed current time

export const ROOMS = [
  { id: 'R101', name: 'Lecture Hall A', capacity: 60,
    equipment: ['projector', 'whiteboard', 'microphone'], blocked: false,
    bookings: [{ start: 600, end: 660 }] },
  { id: 'R102', name: 'Computer Lab 1', capacity: 30,
    equipment: ['computers', 'projector'], blocked: false,
    bookings: [{ start: 720, end: 780 }] },
  { id: 'R103', name: 'Seminar Room', capacity: 15,
    equipment: ['whiteboard', 'tv'], blocked: false,
    bookings: [] },
  { id: 'R104', name: 'Meeting Room B', capacity: 8,
    equipment: ['tv', 'whiteboard'], blocked: true,
    bookings: [] },
  { id: 'R105', name: 'Study Room', capacity: 6,
    equipment: ['whiteboard'], blocked: false,
    bookings: [{ start: 600, end: 660 }, { start: 720, end: 780 }] },
];
