import { ROOMS, NOW } from './data/rooms.js';
import { listEquipment } from './logic/filter.js';
import { evaluate } from './logic/controller.js';
import { toMinutes } from './rules/time.js';
import { renderRoomList, renderResult, renderEmptyState, renderEquipmentOptions } from './ui/render.js';

const $ = (id) => document.getElementById(id);
const state = { attendees: 0, equipment: [], roomId: null, start: NaN, end: NaN, checked: false };

function update() {
  const { visibleRooms, selected, result } = evaluate(state, ROOMS, NOW);
  $('rooms').innerHTML = visibleRooms.length ? renderRoomList(visibleRooms, state.roomId) : renderEmptyState();
  $('result').innerHTML = visibleRooms.length ? renderResult(result, selected, NOW) : '';
}

$('equipment').innerHTML = renderEquipmentOptions(listEquipment(ROOMS), state.equipment);

$('attendees').addEventListener('input', (e) => { state.attendees = Number(e.target.value); update(); });
$('equipment').addEventListener('change', () => {
  state.equipment = [...$('equipment').querySelectorAll('input:checked')].map((i) => i.value);
  update();
});
$('rooms').addEventListener('change', (e) => { state.roomId = e.target.value; update(); }); // F5
$('start').addEventListener('input', (e) => { state.start = toMinutes(e.target.value); update(); });
$('end').addEventListener('input', (e) => { state.end = toMinutes(e.target.value); update(); });
$('check').addEventListener('click', () => { state.checked = true; update(); });

update();
