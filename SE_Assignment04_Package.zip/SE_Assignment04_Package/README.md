# Smart Campus Room Finder - Assignment #04

Software Engineering | Student: Sailaukhan Yenglik (ID 24B031989) | Lecture: Friday 14:00-17:00

Two versions of the same project:

| Folder | What it is |
|---|---|
| `initial/` | Initial version: one room, 3 files, rules copied inside the UI file |
| `final/` | Final version: 5 rooms, filters (capacity, equipment), separate modules |

Git commits: `v1-initial` (initial version) and `v2-final` (final version). Use `git log --oneline`.

## 1. Setup
Needs Node.js 18 or newer.
```
npm install
```

## 2. Run the tests
```
npx vitest run initial     # initial version: 19 tests
npx vitest run final       # final version: 56 tests
npx vitest run             # all tests
```

## 3. Run the app in the browser
The app uses JavaScript modules, so open it through a small local server (not by double-clicking the file).
```
python -m http.server 8000
```
Then open:
- Initial version: http://localhost:8000/initial/
- Final version:   http://localhost:8000/final/

(VS Code "Live Server" also works.)

## 4. Optional: automatic browser check
```
pip install playwright
playwright install chromium
python -m http.server 8765      (keep it running in a second terminal)
python tools/ui_check.py        (8 checks)
```

## 5. Project map (final version)
```
final/
  index.html, styles.css
  src/
    main.js                 reads inputs, keeps state, shows HTML
    data/rooms.js           5 fictional rooms, fixed time NOW = 09:00
    rules/booking.js        booking rules AC1-AC5 (checkRequest, canBook)
    rules/time.js           toMinutes, formatTime
    logic/filter.js         F1 capacity, F2 equipment
    logic/availability.js   check one chosen room
    logic/controller.js     evaluate(state): filter + selected room + result
    ui/render.js            all HTML text (one result card template)
  tests/                    7 test files, 56 tests
```
Other folders: `docs/` (diagrams), `evidence/` (test output, screenshots, measurements), `AI_PROMPTS.md`.
All data is fictional. There is no login, payment, live API or database.
