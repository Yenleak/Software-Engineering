// Smart Campus - room availability (initial version, one room)
// Time = minutes after midnight, same day.
export const MAX_DURATION = 120;
export const DAY_END = 1440;

export function canBook({ start, end, now, blocked, bookings }) {
  if (blocked) return false;                       // AC3
  if (!(start < end)) return false;                // AC1: start >= end
  if (start <= now) return false;                  // AC1: past / starts now
  if (end > DAY_END) return false;                 // AC1: past day end
  if (end - start > MAX_DURATION) return false;    // AC2: > 120 min
  for (const b of bookings) {                      // AC4: touching is OK
    if (start < b.end && end > b.start) return false;
  }
  return true;                                     // AC5: no mutation
}
