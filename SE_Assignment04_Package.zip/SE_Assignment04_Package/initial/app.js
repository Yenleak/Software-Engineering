import { canBook } from './booking.js';

const NOW = 540; // 09:00, fixed current time
const bookings = [{ start: 600, end: 660 }]; // the only room's bookings (hard-coded in the UI file)

function toMin(text) {
  const [h, m] = text.split(':').map(Number);
  return h * 60 + m;
}
function fmt(min) {
  return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0');
}

document.getElementById('check').addEventListener('click', () => {
  const start = toMin(document.getElementById('start').value);
  const end = toMin(document.getElementById('end').value);
  const blocked = document.getElementById('blocked').checked;
  const out = document.getElementById('result');

  if (start >= end) {                                   // validation (also inside canBook)
    out.innerHTML = '<div class="card error">The end time must be after the start time.</div>';
    return;
  }
  if (end - start > 120) {                              // 120-minute rule (also inside canBook)
    out.innerHTML = '<div class="card error">A booking can be at most 120 minutes.</div>';
    return;
  }

  const ok = canBook({ start, end, now: NOW, blocked, bookings });
  if (ok) {
    out.innerHTML = '<div class="card available">Available</div>';
  } else {
    let conflict = null;
    for (const b of bookings) {                         // overlap rule (also inside canBook)
      if (start < b.end && end > b.start) conflict = b;
    }
    const why = conflict ? ' - overlaps ' + fmt(conflict.start) + '-' + fmt(conflict.end) : '';
    out.innerHTML = '<div class="card unavailable">Unavailable' + why + '</div>';
  }
});
